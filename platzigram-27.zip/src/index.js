require('babel-polyfill');
var page = require('page');

require('./homepage');
require('./signup');
require('./signin');
require('./footer');

page();